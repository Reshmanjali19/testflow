const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'data');
// Ensure data directory exists
if (!fs.existsSync(DB_PATH)) fs.mkdirSync(DB_PATH, { recursive: true });

const FILES = {
  users: path.join(DB_PATH, 'users.json'),
  projects: path.join(DB_PATH, 'projects.json'),
  tasks: path.join(DB_PATH, 'tasks.json'),
  members: path.join(DB_PATH, 'members.json'),
};

// Initialize files
Object.values(FILES).forEach(f => {
  if (!fs.existsSync(f)) fs.writeFileSync(f, '[]');
});

function read(file) {
  try {
    return JSON.parse(fs.readFileSync(FILES[file], 'utf8'));
  } catch {
    return [];
  }
}

function write(file, data) {
  fs.writeFileSync(FILES[file], JSON.stringify(data, null, 2));
}

function nextId(arr) {
  return arr.length === 0 ? 1 : Math.max(...arr.map(i => i.id)) + 1;
}

// ---- USERS ----
const Users = {
  all: () => read('users'),
  findById: (id) => read('users').find(u => u.id === id),
  findByEmail: (email) => read('users').find(u => u.email === email.toLowerCase()),
  create: (data) => {
    const users = read('users');
    const user = { id: nextId(users), ...data, email: data.email.toLowerCase(), createdAt: new Date().toISOString() };
    write('users', [...users, user]);
    return user;
  },
};

// ---- PROJECTS ----
const Projects = {
  all: () => read('projects'),
  findById: (id) => read('projects').find(p => p.id === id),
  create: (data) => {
    const projects = read('projects');
    const project = { id: nextId(projects), ...data, createdAt: new Date().toISOString() };
    write('projects', [...projects, project]);
    return project;
  },
  update: (id, data) => {
    const projects = read('projects').map(p => p.id === id ? { ...p, ...data, updatedAt: new Date().toISOString() } : p);
    write('projects', projects);
    return projects.find(p => p.id === id);
  },
  delete: (id) => {
    write('projects', read('projects').filter(p => p.id !== id));
  },
  forUser: (userId) => {
    const memberOf = Members.forUser(userId).map(m => m.projectId);
    return read('projects').filter(p => memberOf.includes(p.id) || p.ownerId === userId);
  },
};

// ---- TASKS ----
const Tasks = {
  all: () => read('tasks'),
  findById: (id) => read('tasks').find(t => t.id === id),
  forProject: (projectId) => read('tasks').filter(t => t.projectId === projectId),
  create: (data) => {
    const tasks = read('tasks');
    const task = { id: nextId(tasks), ...data, status: data.status || 'todo', createdAt: new Date().toISOString() };
    write('tasks', [...tasks, task]);
    return task;
  },
  update: (id, data) => {
    const tasks = read('tasks').map(t => t.id === id ? { ...t, ...data, updatedAt: new Date().toISOString() } : t);
    write('tasks', tasks);
    return tasks.find(t => t.id === id);
  },
  delete: (id) => {
    write('tasks', read('tasks').filter(t => t.id !== id));
  },
  deleteByProject: (projectId) => {
    write('tasks', read('tasks').filter(t => t.projectId !== projectId));
  },
};

// ---- MEMBERS ----
const Members = {
  all: () => read('members'),
  forProject: (projectId) => read('members').filter(m => m.projectId === projectId),
  forUser: (userId) => read('members').filter(m => m.userId === userId),
  find: (projectId, userId) => read('members').find(m => m.projectId === projectId && m.userId === userId),
  add: (data) => {
    const members = read('members');
    const member = { id: nextId(members), ...data, joinedAt: new Date().toISOString() };
    write('members', [...members, member]);
    return member;
  },
  remove: (projectId, userId) => {
    write('members', read('members').filter(m => !(m.projectId === projectId && m.userId === userId)));
  },
  removeByProject: (projectId) => {
    write('members', read('members').filter(m => m.projectId !== projectId));
  },
  updateRole: (projectId, userId, role) => {
    const members = read('members').map(m =>
      m.projectId === projectId && m.userId === userId ? { ...m, role } : m
    );
    write('members', members);
  },
};

module.exports = { Users, Projects, Tasks, Members };
