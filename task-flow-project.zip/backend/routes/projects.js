const express = require('express');
const { body, validationResult } = require('express-validator');
const { Projects, Members, Tasks, Users } = require('../db');
const { authenticate } = require('../auth');

const router = express.Router();
router.use(authenticate);

// Helper: check if user is admin or owner
function requireAdmin(req, res, projectId) {
  const project = Projects.findById(projectId);
  if (!project) { res.status(404).json({ error: 'Project not found' }); return null; }
  if (project.ownerId === req.user.id) return { project, role: 'owner' };
  const member = Members.find(projectId, req.user.id);
  if (!member || member.role !== 'admin') {
    res.status(403).json({ error: 'Admin access required' });
    return null;
  }
  return { project, role: 'admin' };
}

function requireMember(req, res, projectId) {
  const project = Projects.findById(projectId);
  if (!project) { res.status(404).json({ error: 'Project not found' }); return null; }
  if (project.ownerId === req.user.id) return { project, role: 'owner' };
  const member = Members.find(projectId, req.user.id);
  if (!member) { res.status(403).json({ error: 'Not a member of this project' }); return null; }
  return { project, role: member.role };
}

// GET /api/projects - list user's projects
router.get('/', (req, res) => {
  const projects = Projects.forUser(req.user.id);
  const result = projects.map(p => {
    const members = Members.forProject(p.id);
    const tasks = Tasks.forProject(p.id);
    const owner = Users.findById(p.ownerId);
    const myMembership = p.ownerId === req.user.id ? { role: 'owner' } : Members.find(p.id, req.user.id);
    return {
      ...p,
      memberCount: members.length + 1, // +1 for owner
      taskCount: tasks.length,
      completedTasks: tasks.filter(t => t.status === 'done').length,
      overdueTasks: tasks.filter(t => t.dueDate && new Date(t.dueDate) < new Date() && t.status !== 'done').length,
      ownerName: owner?.name,
      myRole: myMembership?.role || 'owner',
    };
  });
  res.json({ projects: result });
});

// POST /api/projects - create project
router.post('/', [
  body('name').trim().notEmpty().withMessage('Project name required'),
  body('description').optional().trim(),
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { name, description } = req.body;
  const project = Projects.create({ name, description: description || '', ownerId: req.user.id });
  // Add owner as admin member too for easy querying
  Members.add({ projectId: project.id, userId: req.user.id, role: 'owner' });
  res.status(201).json({ project });
});

// GET /api/projects/:id
router.get('/:id', (req, res) => {
  const projectId = parseInt(req.params.id);
  const access = requireMember(req, res, projectId);
  if (!access) return;

  const members = Members.forProject(projectId).map(m => {
    const user = Users.findById(m.userId);
    return { ...m, name: user?.name, email: user?.email };
  });
  const tasks = Tasks.forProject(projectId).map(t => {
    const assignee = t.assigneeId ? Users.findById(t.assigneeId) : null;
    return { ...t, assigneeName: assignee?.name };
  });

  res.json({ project: access.project, members, tasks, myRole: access.role });
});

// PUT /api/projects/:id
router.put('/:id', [
  body('name').optional().trim().notEmpty(),
  body('description').optional().trim(),
], (req, res) => {
  const projectId = parseInt(req.params.id);
  const access = requireAdmin(req, res, projectId);
  if (!access) return;

  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { name, description } = req.body;
  const updated = Projects.update(projectId, { ...(name && { name }), ...(description !== undefined && { description }) });
  res.json({ project: updated });
});

// DELETE /api/projects/:id
router.delete('/:id', (req, res) => {
  const projectId = parseInt(req.params.id);
  const project = Projects.findById(projectId);
  if (!project) return res.status(404).json({ error: 'Project not found' });
  if (project.ownerId !== req.user.id) return res.status(403).json({ error: 'Only owner can delete project' });

  Tasks.deleteByProject(projectId);
  Members.removeByProject(projectId);
  Projects.delete(projectId);
  res.json({ message: 'Project deleted' });
});

// ---- MEMBERS ----
// GET /api/projects/:id/members
router.get('/:id/members', (req, res) => {
  const projectId = parseInt(req.params.id);
  if (!requireMember(req, res, projectId)) return;
  const members = Members.forProject(projectId).map(m => {
    const user = Users.findById(m.userId);
    return { ...m, name: user?.name, email: user?.email };
  });
  res.json({ members });
});

// POST /api/projects/:id/members - add member by email
router.post('/:id/members', [
  body('email').isEmail().normalizeEmail(),
  body('role').isIn(['admin', 'member']).withMessage('Role must be admin or member'),
], (req, res) => {
  const projectId = parseInt(req.params.id);
  if (!requireAdmin(req, res, projectId)) return;

  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { email, role } = req.body;
  const user = Users.findByEmail(email);
  if (!user) return res.status(404).json({ error: 'User not found with that email' });

  const project = Projects.findById(projectId);
  if (project.ownerId === user.id) return res.status(400).json({ error: 'User is already the project owner' });

  const existing = Members.find(projectId, user.id);
  if (existing) return res.status(400).json({ error: 'User is already a member' });

  const member = Members.add({ projectId, userId: user.id, role });
  res.status(201).json({ member: { ...member, name: user.name, email: user.email } });
});

// PUT /api/projects/:id/members/:userId - change role
router.put('/:id/members/:userId', [
  body('role').isIn(['admin', 'member']),
], (req, res) => {
  const projectId = parseInt(req.params.id);
  const userId = parseInt(req.params.userId);
  if (!requireAdmin(req, res, projectId)) return;

  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const project = Projects.findById(projectId);
  if (project.ownerId === userId) return res.status(400).json({ error: 'Cannot change owner role' });

  Members.updateRole(projectId, userId, req.body.role);
  res.json({ message: 'Role updated' });
});

// DELETE /api/projects/:id/members/:userId
router.delete('/:id/members/:userId', (req, res) => {
  const projectId = parseInt(req.params.id);
  const userId = parseInt(req.params.userId);
  const project = Projects.findById(projectId);
  if (!project) return res.status(404).json({ error: 'Project not found' });

  // Can remove self, or admin can remove others
  if (userId !== req.user.id) {
    if (!requireAdmin(req, res, projectId)) return;
  }
  if (project.ownerId === userId) return res.status(400).json({ error: 'Cannot remove project owner' });

  Members.remove(projectId, userId);
  res.json({ message: 'Member removed' });
});

module.exports = router;