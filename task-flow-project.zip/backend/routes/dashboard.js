const express = require('express');
const { Projects, Tasks, Members, Users } = require('../db');
const { authenticate } = require('../auth');

const router = express.Router();
router.use(authenticate);

// GET /api/dashboard
router.get('/', (req, res) => {
  const userId = req.user.id;
  const userProjects = Projects.forUser(userId);
  const projectIds = userProjects.map(p => p.id);

  const allTasks = Tasks.all().filter(t => projectIds.includes(t.projectId));
  const myTasks = allTasks.filter(t => t.assigneeId === userId);
  const now = new Date();

  const stats = {
    totalProjects: userProjects.length,
    totalTasks: allTasks.length,
    myTasks: myTasks.length,
    todoTasks: myTasks.filter(t => t.status === 'todo').length,
    inProgressTasks: myTasks.filter(t => t.status === 'in_progress').length,
    doneTasks: myTasks.filter(t => t.status === 'done').length,
    overdueTasks: myTasks.filter(t => t.dueDate && new Date(t.dueDate) < now && t.status !== 'done').length,
    allOverdue: allTasks.filter(t => t.dueDate && new Date(t.dueDate) < now && t.status !== 'done').length,
  };

  // Recent tasks assigned to user
  const recentTasks = myTasks
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 10)
    .map(t => {
      const project = Projects.findById(t.projectId);
      return { ...t, projectName: project?.name };
    });

  // Overdue tasks
  const overdueTasks = allTasks
    .filter(t => t.dueDate && new Date(t.dueDate) < now && t.status !== 'done')
    .map(t => {
      const project = Projects.findById(t.projectId);
      const assignee = t.assigneeId ? Users.findById(t.assigneeId) : null;
      return { ...t, projectName: project?.name, assigneeName: assignee?.name };
    });

  // Project summaries
  const projectSummaries = userProjects.map(p => {
    const tasks = Tasks.forProject(p.id);
    const members = Members.forProject(p.id);
    const myMembership = p.ownerId === userId ? { role: 'owner' } : Members.find(p.id, userId);
    return {
      ...p,
      taskCount: tasks.length,
      completedTasks: tasks.filter(t => t.status === 'done').length,
      inProgressTasks: tasks.filter(t => t.status === 'in_progress').length,
      memberCount: members.length,
      myRole: myMembership?.role || 'owner',
    };
  });

  res.json({ stats, recentTasks, overdueTasks, projects: projectSummaries });
});

module.exports = router;