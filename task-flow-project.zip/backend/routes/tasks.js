const express = require('express');
const { body, validationResult } = require('express-validator');
const { Tasks, Projects, Members, Users } = require('../db');
const { authenticate } = require('../auth');

const router = express.Router({ mergeParams: true });
router.use(authenticate);

function getMembership(req, res, projectId) {
  const project = Projects.findById(projectId);
  if (!project) { res.status(404).json({ error: 'Project not found' }); return null; }
  if (project.ownerId === req.user.id) return { project, role: 'owner' };
  const member = Members.find(projectId, req.user.id);
  if (!member) { res.status(403).json({ error: 'Not a member of this project' }); return null; }
  return { project, role: member.role };
}

// GET /api/projects/:projectId/tasks
router.get('/', (req, res) => {
  const projectId = parseInt(req.params.projectId);
  if (!getMembership(req, res, projectId)) return;

  const tasks = Tasks.forProject(projectId).map(t => {
    const assignee = t.assigneeId ? Users.findById(t.assigneeId) : null;
    const creator = Users.findById(t.createdBy);
    return { ...t, assigneeName: assignee?.name, createdByName: creator?.name };
  });
  res.json({ tasks });
});

// POST /api/projects/:projectId/tasks
router.post('/', [
  body('title').trim().notEmpty().withMessage('Title required'),
  body('description').optional().trim(),
  body('status').optional().isIn(['todo', 'in_progress', 'done']),
  body('priority').optional().isIn(['low', 'medium', 'high']),
  body('dueDate').optional().isISO8601(),
  body('assigneeId').optional().isInt(),
], (req, res) => {
  const projectId = parseInt(req.params.projectId);
  if (!getMembership(req, res, projectId)) return;

  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { title, description, status, priority, dueDate, assigneeId } = req.body;

  // Validate assignee is a project member
  if (assigneeId) {
    const project = Projects.findById(projectId);
    const isOwner = project.ownerId === parseInt(assigneeId);
    const isMember = Members.find(projectId, parseInt(assigneeId));
    if (!isOwner && !isMember) return res.status(400).json({ error: 'Assignee must be a project member' });
  }

  const task = Tasks.create({
    title,
    description: description || '',
    status: status || 'todo',
    priority: priority || 'medium',
    dueDate: dueDate || null,
    assigneeId: assigneeId ? parseInt(assigneeId) : null,
    projectId,
    createdBy: req.user.id,
  });

  const assignee = task.assigneeId ? Users.findById(task.assigneeId) : null;
  res.status(201).json({ task: { ...task, assigneeName: assignee?.name } });
});

// PUT /api/projects/:projectId/tasks/:id
router.put('/:id', [
  body('title').optional().trim().notEmpty(),
  body('description').optional().trim(),
  body('status').optional().isIn(['todo', 'in_progress', 'done']),
  body('priority').optional().isIn(['low', 'medium', 'high']),
  body('dueDate').optional({ nullable: true }),
  body('assigneeId').optional({ nullable: true }),
], (req, res) => {
  const projectId = parseInt(req.params.projectId);
  const taskId = parseInt(req.params.id);
  const access = getMembership(req, res, projectId);
  if (!access) return;

  const task = Tasks.findById(taskId);
  if (!task || task.projectId !== projectId) return res.status(404).json({ error: 'Task not found' });

  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const updates = {};
  ['title', 'description', 'status', 'priority', 'dueDate'].forEach(f => {
    if (req.body[f] !== undefined) updates[f] = req.body[f];
  });
  if (req.body.assigneeId !== undefined) {
    updates.assigneeId = req.body.assigneeId ? parseInt(req.body.assigneeId) : null;
  }

  const updated = Tasks.update(taskId, updates);
  const assignee = updated.assigneeId ? Users.findById(updated.assigneeId) : null;
  res.json({ task: { ...updated, assigneeName: assignee?.name } });
});

// DELETE /api/projects/:projectId/tasks/:id
router.delete('/:id', (req, res) => {
  const projectId = parseInt(req.params.projectId);
  const taskId = parseInt(req.params.id);
  const access = getMembership(req, res, projectId);
  if (!access) return;

  const task = Tasks.findById(taskId);
  if (!task || task.projectId !== projectId) return res.status(404).json({ error: 'Task not found' });

  // Only admin/owner/creator can delete
  if (task.createdBy !== req.user.id && access.role === 'member') {
    return res.status(403).json({ error: 'Only task creator or admin can delete tasks' });
  }

  Tasks.delete(taskId);
  res.json({ message: 'Task deleted' });
});

// GET dashboard stats for all user's tasks
router.get('/dashboard', (req, res) => {
  // This is mounted differently — handled in main routes
});

module.exports = router;
