const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

let users = [];
let projects = [];
let tasks = [];

// Signup
app.post('/api/signup', (req, res) => {
    const { name, email, password, role } = req.body;

    if(users.find(u => u.email === email)){
        return res.status(400).json({ message: 'User already exists' });
    }

    const user = {
        id: Date.now(),
        name,
        email,
        password,
        role
    };

    users.push(user);

    res.json({ message: 'Signup successful', user });
});

// Login
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;

    const user = users.find(
        u => u.email === email && u.password === password
    );

    if(!user){
        return res.status(401).json({ message: 'Invalid credentials' });
    }

    res.json({ message: 'Login successful', user });
});

// Create Project
app.post('/api/projects', (req, res) => {
    const project = {
        id: Date.now(),
        ...req.body
    };

    projects.push(project);

    res.json(project);
});

// Get Projects
app.get('/api/projects', (req, res) => {
    res.json(projects);
});

// Create Task
app.post('/api/tasks', (req, res) => {
    const task = {
        id: Date.now(),
        status: 'Pending',
        ...req.body
    };

    tasks.push(task);

    res.json(task);
});

// Get Tasks
app.get('/api/tasks', (req, res) => {
    res.json(tasks);
});

// Update Task Status
app.put('/api/tasks/:id', (req, res) => {
    const id = Number(req.params.id);

    tasks = tasks.map(task =>
        task.id === id
            ? { ...task, status: req.body.status }
            : task
    );

    res.json({ message: 'Task updated successfully' });
});

// Dashboard
app.get('/api/dashboard', (req, res) => {

    const completed = tasks.filter(t => t.status === 'Completed').length;
    const pending = tasks.filter(t => t.status === 'Pending').length;
    const overdue = tasks.filter(t => t.status === 'Overdue').length;

    res.json({
        totalProjects: projects.length,
        totalTasks: tasks.length,
        completed,
        pending,
        overdue
    });
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});