# 🚀 TaskFlow Project Management Web App

## 📌 Overview
TaskFlow is a role-based project management application where users can:
- Signup/Login
- Create projects
- Assign and track tasks
- View dashboard statistics
- Manage Admin/Member roles

---

## ✨ Features
- Authentication
- Role-based Access
- Project Management
- Task Tracking
- Dashboard
- REST APIs

---

## 🛠️ Tech Stack
### Frontend
- HTML
- CSS
- JavaScript

### Backend
- Node.js
- Express.js

---

## ▶️ Run Backend

```bash
cd backend
npm install
npm start
```

Backend runs at:
http://localhost:3000

---

## ▶️ Run Frontend

Open:
frontend/index.html

---

## 🌐 Railway Deployment
Deploy backend using:
https://railway.app

---

## 👩‍💻 Author
Reshma Reshmanjali