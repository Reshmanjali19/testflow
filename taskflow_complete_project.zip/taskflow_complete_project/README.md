# TaskFlow Project

## Features
- Authentication APIs
- Project Management
- Task Management
- Dashboard
- Role-Based Structure

## Run Backend

```bash
cd backend
npm install
npm start
```

## Run Frontend
Open frontend/index.html in browser.

## Tech Stack
- Node.js
- Express.js
- HTML/CSS/JavaScript