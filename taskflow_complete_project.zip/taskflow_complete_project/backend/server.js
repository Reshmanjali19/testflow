const express = require('express');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

let users = [];
let projects = [];
let tasks = [];

app.get('/', (req, res) => {
    res.json({ message: 'TaskFlow Backend Running' });
});

app.post('/signup', (req, res) => {
    const user = req.body;
    users.push(user);
    res.json({ message: 'User registered successfully' });
});

app.post('/login', (req, res) => {
    const { email, password } = req.body;

    const user = users.find(
        u => u.email === email && u.password === password
    );

    if(user){
        return res.json({ success: true, user });
    }

    res.status(401).json({ success: false, message: 'Invalid credentials' });
});

app.post('/projects', (req, res) => {
    const project = { id: Date.now(), ...req.body };
    projects.push(project);
    res.json(project);
});

app.get('/projects', (req, res) => {
    res.json(projects);
});

app.post('/tasks', (req, res) => {
    const task = { id: Date.now(), status: 'Pending', ...req.body };
    tasks.push(task);
    res.json(task);
});

app.get('/tasks', (req, res) => {
    res.json(tasks);
});

app.put('/tasks/:id', (req, res) => {
    const id = Number(req.params.id);

    tasks = tasks.map(task =>
        task.id === id ? { ...task, status: req.body.status } : task
    );

    res.json({ message: 'Task updated' });
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});